This project is developed by Bhavish Khanna Narayanan and Meet Shah.

Steps to run the program:-
Pre-requisites: In order to run the program, it is essential that a JDK environment is installed in the target system. 

Compilation of the program: execute the following from the bxn170002 folder; javac BoundedQueue.java

Post the successful completion of the compilation, the program can be executed with the following command; java BoundedQueue

Driver program:-

This program performs the following actions on:-

Bounded Queue Operations:
1. Offer
2. Poll
3. Peek
4. Print Size
5. Clear Queue
6. Convert to Array
7. Print Queue
8. Is Empty?
