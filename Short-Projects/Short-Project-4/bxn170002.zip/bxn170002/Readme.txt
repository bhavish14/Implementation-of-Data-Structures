This project is developed by Bhavish Khanna Narayanan and Meet Shah.

Steps to run the program:-
Pre-requisites: In order to run the program, it is essential that a JDK environment is installed in the target system. 

Compilation of the program: execute the following from the bxn170002 folder; javac BinarySearchTree.java

Post the successful completion of the compilation, the program can be executed with the following command; java BinarySearchTree

Driver program:-

This program peforms the following actions on:-

Binary Search Tree Operations:
1. Add
2. Remove
3. Contains
4. Min
5. Max
6. toArray