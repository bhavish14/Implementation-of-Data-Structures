This project is developed by Bhavish Khanna Narayanan and Swapna Chintapalli.

Steps to run the program:-
Pre-requisites: In order to run the program, it is essential that a JDK environment is installed in the target system. 

Compilation of the program: execute the following from the bxn170002 folder; javac KLargest.java

Post the successful completion of the compilation, the program can be executed with the following command; java KLargest

Driver program:-

This program finds the k largest elements from an array.-
