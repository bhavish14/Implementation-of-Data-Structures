import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class DoublyLinkedList<T> extends SinglyLinkedList<T> {
    static class Entry<E> extends SinglyLinkedList.Entry<E> {
        Entry<E> prev;

        Entry(E x, Entry<E> next, Entry<E> prev) {
            super(x, next);
            this.prev = prev;
        }

    }

    public DoublyLinkedList() {
        head = new DoublyLinkedList.Entry<>(null, null, null);
        tail = head;
        size = 0;
    }

    // Add new elements to the end of the list
    public void add(T x) {
        add(new DoublyLinkedList.Entry<>(x, null, (Entry<T>) tail));
    }

    public void add(DoublyLinkedList.Entry<T> ent) {
        super.add(ent);
    }



    public Iterator<T> iterator() { return new DoublyLinkedList.DLLIterator(); }

    protected class DLLIterator extends  SLLIterator implements Iterator<T> {
        Entry<T> cursor, prev, next;

        DLLIterator() {
            super();
            next = null;
        }

        public void remove() {

            cursor = DoublyLinkedList.Entry.class.cast(super.cursor);
            next = DoublyLinkedList.Entry.class.cast(cursor.next);
            prev = cursor.prev;
            //System.out.print(cursor.next.element);
            if (next != null) {
                next.prev = prev;
            }
            super.remove();

        }

        public boolean hasPrev() {
            return cursor.prev != null;
        }

        public void addMiddle(T x) {
            cursor = DoublyLinkedList.Entry.class.cast(super.cursor);
            next = DoublyLinkedList.Entry.class.cast(cursor.next);
            addMiddle(new DoublyLinkedList.Entry<T>(x, next, cursor));
        }

        public void addMiddle(DoublyLinkedList.Entry<T> ent) {
            cursor = DoublyLinkedList.Entry.class.cast(super.cursor);
            next = DoublyLinkedList.Entry.class.cast(cursor.next);
            prev = cursor.prev;
            cursor.next = ent;
            next.prev = ent;
        }


        /*
        public T prev() {
            next = super.cursor;
            cursor = super.cursor.prev;
            prev = super.cursor.prev;
            ready = true;
            return cursor.element;
        }

        public boolean test() {
            return super.cursor.prev != null;
        }*/
    }

    public static void main(String[] args) throws NoSuchElementException {
        int n = 5;
        if(args.length > 0) {
            n = Integer.parseInt(args[0]);
        }

        DoublyLinkedList<Integer> lst = new DoublyLinkedList<>();
        for(int i=1; i<=n; i++) {
            lst.add(Integer.valueOf(i));
        }
        lst.printList();

       Iterator<Integer> it = lst.iterator();

        Scanner in = new Scanner(System.in);
        whileloop:
        while(in.hasNext()) {
            int com = in.nextInt();
            switch(com) {
                case 1:  // Move to next element and print it
                    if (it.hasNext()) {
                        System.out.println(it.next());
                    } else {
                        break whileloop;
                    }
                    break;
                case 2:  // Remove element
                    if (it.hasNext()) {
                        it.next();
                        it.remove();
                        lst.printList();
                    }
                    break;
                case 3:
                    System.out.println(it.getClass());
                    it.addMiddle(Integer(10));
                    break;
                default:  // Exit loop
                    break whileloop;
            }
        }
        lst.printList();

    }
}